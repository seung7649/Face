%% Demo code ver. 02/08/2020
%==================================================================================================================================================
% Spontaneous generation of face recognition in untrained deep neural networks
% Baek S*, Song M*, Kim G, Jang J & Paik SB (* Equally contributed)
% link: https://www.biorxiv.org/content/10.1101/857466v1
% doi: 10.1101/857466
%
% Prerequirement 
% 1) MATLAB 2018b or later version is recommended.
% 2) Install deeplearning toolbox. 
%
% Output of the code
% Below results for permuted (randomized) AlexNet will
% be shown.
% 1) Weight of pretrained AlexNet 
% 2) Weight of permuted AlexNet 
% 3) Average tuning curve of face selective neurons in permuted AlexNet
% 4) Number of selective neurons in permuted AlexNet
%
% Contacts : Seungdae Baek (seung7649@kaist.ac.kr)
%==================================================================================================================================================
close all;clc;clear;
rng(2)                                                      % fixed random seed for regenerating same result
toolbox_chk;                                                % checking matlab version and toolbox
tic
load('flg.mat')                                                                                   % flag for runing each Figure
if flg1+flg2+flg3+flg4 > 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% Setting parameters
    fontSize = 20;
    inpSize = 227;                                              % width ( or height of images )
    nIMG = 100;                                                 % number of images on each class in the dataset
    nCLS = 16;                                                  % number of total object classes in the dataset
    indFace = 1;                                                % index of face class in the dataset
    layersSet = {'relu1', 'relu2', 'relu3', 'relu4', 'relu5'};	% names of feature extraction layers
    indLayer  = 5;                                              % index of target layer
    stdArray = [0.4 0.6 0.8 1];                                 % std of gaussian kernel for randomly initialized network
    pThr = 0.01;                                                % p-value threshold of selective response
    dirIMG = 'Dataset';                                         % set data directory list of class names
    dirList=dir(dirIMG); STR_LABEL = cell(1,nCLS);              %  list of class names
    for ii = 1:nCLS
        STR_LABEL{ii} = dirList(ii+2).name;
    end
    STR_LABEL{1} = 'Face';
    
    %% Step 1. Loading image dataset
    tic
    disp('Step1 : Loading image dataset ... (~ 15 sec)');
    dirIMG = 'Dataset';
    imd = imageDatastore(dirIMG,'IncludeSubfolders',true,'LabelSource','foldernames');         % load image dataset
    imds = augmentedImageDatastore([inpSize inpSize 3],imd,'ColorPreprocessing','gray2rgb');   % resize image dataset
    IMG_M = zeros(inpSize,inpSize,3,nIMG*nCLS);
    for nn = 1:nIMG*nCLS
        IMG_temp  = imresize(double(imread(imd.Files{nn})), [inpSize inpSize]);
        IMG_M(:,:,:,nn) = IMG_temp;
    end
    toc
    %% Step 2. Loading pretrained Alexnet and permute kernel of Alexnet randomly
    tic
    disp('Step2: Loading pretrained Alexnet and permute kernel of Alexnet randomly ... (~ 2 sec)');
    load('Alexnet_2018b.mat');                                                          % load pretrained Alexnet produced by Matlab 2018b
    net_rand = fun_weight_permutation(net);                                             % permutation of weight kernel on each layer
    Cell_net_gau = cell(1,length(stdArray));
    for ii = 1:length(stdArray)
        Cell_net_gau{ii} = fun_weight_randomInit(net,stdArray(ii));                    % random initialization of weight kernel on each layer
    end
    toc
    
    %% Step 3. Measuring responses of neurons in the target layer
    tic
    disp('Step3: Measuring responses of neurons in the target layer ... (~ 20 sec)');
    act = activations(net,imds,layersSet{indLayer});                                                        % response of all neurons to all images on pretrained AlexNet
    act_rand = activations(net_rand,imds,layersSet{indLayer});                                              % response of all neurons to all images on permuted AlexNet
    
    act_M = zeros(numel(act)/nIMG/nCLS,nCLS,nIMG);
    act_rand_M = zeros(numel(act_rand)/nIMG/nCLS,nCLS,nIMG);
    for ii = 1:nCLS
        act_M(:,ii,:) = reshape(act(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG), numel(act)/nIMG/nCLS,nIMG);     % reshape response of all neurons to all images on pretrained AlexNet
        act_rand_M(:,ii,:) = reshape(act_rand(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG),numel(act)/nIMG/nCLS,nIMG);    % reshape response of all neurons to all images on permuted AlexNet
    end
    
    act_gau_C = cell(1,length(stdArray));
    for ii =1:length(stdArray)
        net_gau = Cell_net_gau{ii};                                                                         % load ramdomly intialized AlexNet with ii th standard deviation.
        act_gau = activations(net_gau,imds,layersSet{indLayer});                                            % response of all neurons to all images on ramdomly intialized AlexNet
        act_gau_M = zeros(numel(act_gau)/nIMG/nCLS,nCLS,nIMG);
        for jj = 1:nCLS
            act_gau_M(:,jj,:) = reshape(act_gau(:,:,:,(jj-1)*nIMG+1:(jj)*nIMG),numel(act)/nIMG/nCLS,nIMG);  % reshape response of all neurons to all images on permuted AlexNet
        end
        act_gau_C{ii} = act_gau_M;
    end
    toc
    clearvars act act_rand act_gau net_gau Res_gau_mat
    
    %% Step 4. Finding selective neuron to each class
    disp('Step4: Find selective neuron to each class ... (~ 4 min)');
    tic
    %%% Step4-1: Find selective neuron to each class in pretrained AlexNet
    [~,cellSC] = max(mean(act_M,3),[],2);                                           %find maximum respond class
    cellSB = findSelCell(act_M,nCLS,cellSC,pThr,0);                                 %test whether cell is significantly selective or not
    
    %%% Step4-2: Find selective neuron to each class in permuted AlexNet
    [~,cellSC_rand] = max(mean(act_rand_M,3),[],2);                                  %find maximum respond class
    cellSB_rand = findSelCell(act_rand_M,nCLS,cellSC_rand,pThr,0);                   %test whether cell is significantly selective or not
    
    %%% Step4-3: Find selective neuron to each class in randomly initialized AlexNet
    cellSC_gau_C = cell(length(stdArray)); cellSB_gau_C = cell(length(stdArray));
    
    for ii = 1:length(stdArray)
        act_gau_M = act_gau_C{ii};
        [~,cellSC_gau] = max(mean(act_gau_M,3),[],2);                               %find maximum respond class
        cellSB_gau = findSelCell(act_gau_M,nCLS,cellSC_gau,pThr,1);                 %test whether cell is significantly selective or not
        cellSC_gau_C{ii} = cellSC_gau; cellSB_gau_C{ii} = cellSB_gau;
    end
    toc
    
    %% Step 5. Measuring face-selectivity of each neurons
    tic
    disp('Step5: Measure selectivity of face selctive neurons ... (~ 1 sec)')
    %%% Step5-1: Measure selectivity of face selctive neurons in permuted AlexNet
    faceSI_rand = measureSI(act_rand_M,cellSB_rand,cellSC_rand,indFace,nCLS,nIMG,1);
    
    %%% Step5-2: Measure selectivity of face selctive neurons in initialized AlexNet
    faceSI_gau_C = cell(1,length(stdArray));
    for ii = 1:length(stdArray)
        act_gau_M = act_gau_C{ii};
        cellSC_gau = cellSC_gau_C{ii};
        cellSB_gau = cellSB_gau_C{ii};
        faceSI_gau_C{ii} = measureSI(act_gau_M,cellSB_gau,cellSC_gau,indFace,nCLS,nIMG,1);
    end
    toc
    
    
    %% Step 6. Analyzing and showing results
    %% Figure 0 : Showing stimulus dataset
    disp('Showing stimulus ... (~ 2 sec)')
    tic
    imagesPerClass = 10;
    imagesInMontage = cell(imagesPerClass,nCLS);
    for cc = 1:nCLS
        idx = find(double(imd.Labels) == cc);
        ind_pick = idx(randperm(length(idx),imagesPerClass));
        for ii = 1:imagesPerClass
            imagesInMontage{cc,ii} = imread(imds.Files{ind_pick(ii)});
        end
    end
    figure
    montage({imagesInMontage{:}},'Size',[imagesPerClass,nCLS]);
    name = STR_LABEL; set(gca,'xticklabel',name);
    toc
    title('Face vs non-face dataset (Supplementary Figure.1)','FontSize',15)
end

if flg1 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 1 : Face-selectivity in pre-trained AlexNet for non-face natural image classification  
disp('Figure 1 ... (~ 1 min)')
tic
Result_Figure1;
toc
end

if flg2 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 2 : Face-selectivity in permuted AlexNet 
disp(['Figure 2... (~ 1 min)'])
tic
Result_Figure2;
toc
end

if flg3 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 3 : View-point invariant characteristics of face-selective neurons
disp(['Figure 3...(~ 6 min)'])
tic
Result_Figure3;
toc
end

if flg4 == 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Figure 4 : Face-selectivity induced by variation in convolutional weights
disp(['Figure 4...(~ 5 min)'])
tic
Result_Figure4;
toc
end



