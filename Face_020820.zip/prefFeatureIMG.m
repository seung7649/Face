function RF_C = prefFeatureIMG(act_M,inpSize,IMG_M,cell_ind_list)
act_thre = mean(act_M,'all');                                               % set threshold for averaging image
RF_C = cell(1,length(cell_ind_list));
IMG_M_perm = permute(IMG_M,[4,1,2,3]); act_M_perm = permute(act_M,[3,2,1]);
for ii = 1:length(cell_ind_list)
    cell_idx = cell_ind_list(ii);
    cell_act = act_M_perm(:,:,cell_idx); cell_act = cell_act(:);            % get response of target cell
    cell_act_thre = (cell_act>act_thre).*cell_act;                          % get supra-thresholded response of target cell
    cell_act_rep = repmat(cell_act_thre,[1 inpSize inpSize 3]);             % use supra-thresholded response as weight
    RF_C{ii} = squeeze(sum(cell_act_rep.*IMG_M_perm,1))/sum(cell_act_thre); % calculate preferred feature image as weighted sum of images
end