%% Figure 2 : Face-selectivity in permuted AlexNet 
% disp(['Figure 2... (~ 1 min)'])
tic
%%% Figure 2 : Face-selectivity in permuted AlexNet
% act_rand_M = Res_rand_mat;
face_SB = cellSB_rand'.*(cellSC_rand==1);
face_ind_rand = find(face_SB);

%%% Figure 2a : The untrained AlexNet by randomly permuting the weights in each convolutional layer 
layers_ind = [2,6,10,12,14]; % target layers: conv1~5
vis_N = 3; % number of filters to visualize
figure('units','normalized','outerposition',[0 0 0.5 1])
for ii = 1:length(layers_ind)
    filter_pre = net.Layers(layers_ind(ii)).Weights; ...
        sztmp = size(filter_pre,4); indtmpp=randi(sztmp, [1,vis_N]);                                        % load pre-trained filter
    filter_perm = net_rand.Layers(layers_ind(ii)).Weights; ...
        sztmp_r = size(filter_perm,4); indtmpp_r=randi(sztmp_r, [1,vis_N]);                                 % load permutedre filter
    for jj = 1:length(indtmpp)
        ax=subplot(5,7,7*(ii-1)+jj);
        tmp = squeeze(filter_pre(:,:,1,indtmpp(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_pre(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])    % plot pre-trained filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',fontSize_legend); end
        ax=subplot(5,7,7*(ii-1)+jj+4);
        tmp = squeeze(filter_perm(:,:,1,indtmpp_r(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_perm(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])   % plot permutedre filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',fontSize_legend); end
    end
end
sgtitle('Left: pretrained AlexNet, Right: permuted AlexNet','FontSize',fontSize_title);
colormap(gray)

%%% Figure 2b: Response matrix of face-selective neurons in permuted AlexNet
actFaceCell = reshape(permute(act_rand_M(face_ind_rand,:,:),[3,2,1]),...
    [nCLS*nIMG,length(face_ind_rand)])';                                            % find activity of face-selective neurons
actFaceCell_norm = actFaceCell./repmat(max(actFaceCell,[],2),[1, nCLS*nIMG]);       % Normalize response of each neuron with thier maximum response 
[~,indSort] = sort(mean(actFaceCell_norm(:,1:nIMG),2),'descend');                   % Sorting with descending order

figure('units','normalized','outerposition',[0 0 0.5 1]); subplot(2,1,1)
imagesc(actFaceCell_norm(indSort,:));
caxis([0 1]); colorbar; colormap(hot); 
xlabel('Image Index','FontSize',fontSize_label); ylabel('Neuron Index','FontSize',fontSize_label);
title('Face-selective response in permuted AlexNet','FontSize',fontSize_title)

%%% Figure 2b : Average tuning curve of face-selective neurons in permuted AlexNet 
TCface = zeros(length(face_ind_rand),nCLS);
for cc = 1:nCLS
    TCface(:,cc) = mean(actFaceCell_norm(:,(cc-1)*nIMG+1:(cc)*nIMG),2);                      % Calculate average response for each class per neuron: tuning curve
end

subplot(2,1,2); hold on 
for ii = 1:size(TCface,1)
    h= plot([0:nCLS+1],[mean(TCface(ii,:)) TCface(ii,:) ...
        mean(TCface(ii,:))],'Color',[0 0 0],'linewidth',1.5);                               % Plot tuning curves for each neuron
    h.Color(4)=0.01;                                                                        % Add transparency to line
end
h1 = plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) ... 
    mean(mean(TCface,1),'all')],'Color',[0.98, 0.73 0.23],'linewidth',3);
xlim([0.5 16.5]);
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);       % Plot average tuning curve
ylabel(['Normalized Response'],'FontSize',fontSize_label)
legend(h1,'Averaged','Location','northeast','FontSize',fontSize_legend)
title('Average tuning curve of face-selective neurons in permuted AlexNet (Figure 2b)','FontSize',fontSize_title)      


%%% Figure 2f-g 
%%% i) preferred feature image : Face, No selectivity
[~,ind_SI_sort] = sort(faceSI_rand,'descend');                 % sort face selectivity
trg_idx = 3; cell_list = face_ind_rand(ind_SI_sort(trg_idx));   % get strongly selective cell to face
SB_list = find(cellSB_rand); NSB_list = find(~cellSB_rand);
[~,ind_maxres] = max(mean(mean(act_rand_M(NSB_list,:,:),2),3));
cell_list = [cell_list NSB_list(ind_maxres)];                   % get not selective cell to face with stronges activity amplitude
Cell_RF = prefFeatureIMG(act_rand_M,inpSize,IMG_M,cell_list);   % get preferred feature images

figure('units','normalized','outerposition',[0 0 0.5 1])         % plot preferred feature images
for ii = 1:length(cell_list)
    if ii == 1
        subplot(3,5,[1,2,6,7])                           
        imshow(uint8(Cell_RF{ii}));         
        title('Face','FontSize',fontSize_label)   
    else
        subplot(3,5,[4,5,9,10])                              
        imshow(uint8(Cell_RF{ii}));         
        title('No selectivity','FontSize',fontSize_label) 
    end
end

%%% ii) preferred feature images with various selectivity indices
trg_idx = [3, 83, 163, 325, 406];
cell_list = face_ind_rand(ind_SI_sort(trg_idx));                    % get face selective cell in descending order of face selectivity
Cell_RF_SI = prefFeatureIMG(act_rand_M,inpSize,IMG_M,cell_list);    % get preferred feature images
                                                      % plot preferred feature images
for ii = 1:length(cell_list)
    subplot(3,5,10+ii) 
    imshow(uint8(Cell_RF_SI{ii})); title(['Rank ',num2str(trg_idx(ii))]);
end
sgtitle(['Preferred feature images of sample neurons in premuted AlexNet Conv5 layer (Figure 2f-g)'],'FontSize',fontSize_title);  

%%% Figure 2h : Performance on the Face classification task using face-selective neurons in permuted AlexNet
Y = imd.Labels; Label = Y == categorical(cellstr('0_Face'));
N = 30; nType = 2;                                          % set number of trial and number of classification category, here it is set 2: face vs non-face                                      
nCellList = logspace(log10(1/length(face_ind_rand)),0,20);  % set list of number of cell using for SVM training
correctRat = zeros(N,length(nCellList),nType);
for nn = 1:N
    train_act = []; train_label = [];                                   % Set training set
    test_act = []; test_label = [];                                     % Set test set
    for ii = 1:nCLS
        actCLS = transpose(squeeze(act_rand_M(:,ii,:)));
        labelCLS = Label(nIMG*(ii-1)+1:nIMG*ii);
        
        if ii == indFace                                                % set train and test samples (face class: 60 samples for train and 30 samples for test)
            perm_temp = randperm(100,90);                               % set 90 mother samples
            train_act = [train_act; actCLS(perm_temp(1:60),:)];         % pick 60 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:60),:)]; 
            test_act = [test_act; actCLS(perm_temp(61:90),:)];          % pick 30 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(61:90),:)];
        else
            perm_temp = randperm(100,6);                                % set 6 mother samples
            train_act = [train_act; actCLS(perm_temp(1:4),:)];          % pick 4 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:4),:)]; 
            test_act = [test_act; actCLS(perm_temp(5:6),:)];            % pick 2 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(5:6),:)];
        end
    end
       
    for p = 1:length(nCellList)

        %%% Type 1 SVM : face neurons
        ind_perm = randperm(length(face_ind_rand),...
            round(length(face_ind_rand)*nCellList(p)));                     % pick random face-selective cell with different number
        train_act_face = train_act(:,face_ind_rand(ind_perm));              % training set using only face cell
        test_act_face = test_act(:,face_ind_rand(ind_perm));                % testing set using only face cell
        Mdl = fitcecoc(train_act_face,train_label);                         % Train SVM
        predict_label = predict(Mdl,test_act_face);                         % Predcit test label
        correctRat(nn,p,1) = length(find(test_label == predict_label))...
        ./length(test_label);                                               % Calculate correct ratio
    
        %%% Type 2 SVM : non-selective neurons
        ind_perm = randperm(length(NSB_list),round(length(face_ind_rand)*nCellList(p))); 
        train_act_noSel = train_act(:,NSB_list(ind_perm));                  % training set using only no-selectivity cell
        test_act_noSel = test_act(:,NSB_list(ind_perm));                    % testing set using only no-selectivity cell
        Mdl = fitcecoc(train_act_noSel,train_label);                            % Train SVM
        predict_label = predict(Mdl,test_act_noSel);                        % Predcit test label
        correctRat(nn,p,2) = length(find(test_label == predict_label))...
        ./length(test_label);                                               % Calculate correct ratio
    end
end

figure('units','normalized','outerposition',[0 0 0.5 1])
hold on
shadedErrorBar(nCellList.*100,mean(correctRat(:,:,1),1),std(correctRat(:,:,1),1),'lineprops',{'r','markerfacecolor','r'});
shadedErrorBar(nCellList.*100,mean(correctRat(:,:,2),1),std(correctRat(:,:,2),1),'lineprops',{'k','markerfacecolor','k'});
h1 = plot(nCellList.*100,mean(correctRat(:,:,1),1),'r','linewidth',3);
h2 = plot(nCellList.*100,mean(correctRat(:,:,2),1),'k','linewidth',3);
xlim([0 100])
ylim([0.49 1.01])
set(gca, 'XScale', 'log')
xlabel('Neurons considered (%)','FontSize',fontSize_label)  
ylabel('Correct ratio','FontSize',fontSize)
title('SVM performance of face classification task in permuted AlexNet (Figure 2h)','FontSize',fontSize_title)  
legend([h1 h2],'Face-selective neurons','Neurons with no selectivity','Location','southeast','FontSize',fontSize_legend) 
toc