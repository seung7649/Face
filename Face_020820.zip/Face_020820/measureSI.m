function SI_list_face = measureSI(act_M,SB,SC,indFace,nCLS,nIMG,trgCLS)
ind = find(SB'.*(SC==trgCLS));                                                          % find cells significantly selective to face
SI_list_face = zeros(1,length(ind));
for jj = 1:length(ind)                                                                  % Measure selective index for each cell
    temp_ind = ind(jj);                                                                 % set a target cell
    act_M_jj = squeeze(act_M(temp_ind,:,:));                                            % activity of target cell
    act_M_other = act_M_jj; act_M_other(indFace,:) = [];                               % non-face activity of target cell
    prob_temp = zeros(1,nIMG);
    for ii = 1:nIMG
        resp_temp = act_M_jj(indFace,ii);                                              % activity amplitude of target face image
        prob_temp(ii) = (1/nIMG)*prod(sum(act_M_other<resp_temp,2))/(nIMG^(nCLS-1));    % count number of other image induce larger activity than target face image
        
    end
    SI_list_face(jj) = sum(prob_temp);
end
