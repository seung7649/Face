%% Demo code ver. 01/09/2020
%==================================================================================================================================================
% Spontaneous generation of face recognition in untrained deep neural networks
% Baek S*, Song M*, Kim G, Jang J & Paik SB (* Equally contributed)
% link: https://www.biorxiv.org/content/10.1101/857466v1
% doi: 10.1101/857466
%
% Prerequirement 
% 1) MATLAB 2018b or later version is recommended.
% 2) Install deeplearning toolbox. 
%
% Output of the code
% Below results for permuted (randomized) AlexNet will
% be shown.
% 1) Weight of pretrained AlexNet 
% 2) Weight of permuted AlexNet 
% 3) Average tuning curve of face selective neurons in permuted AlexNet
% 4) Number of selective neurons in permuted AlexNet
%
% Contacts : Seungdae Baek (seung7649@kaist.ac.kr)
%==================================================================================================================================================
close all;clc;clear;
rng(2)                                                      % fixed random seed for regenerating same result
toolbox_chk;                                                % checking matlab version and toolbox
tic
%% Setting parameters
fontSize = 20;
inpSize = 227;                                              % width ( or height of images ) 
nIMG = 100;                                                 % number of images on each class in the dataset
nCLS = 16;                                                  % number of total object classes in the dataset
indFace = 1;                                                % index of face class in the dataset
layersSet = {'relu1', 'relu2', 'relu3', 'relu4', 'relu5'};	% names of feature extraction layers
indLayer  = 5;                                              % index of target layer 
stdArray = [0.4 0.6 0.8 1];                                 % std of gaussian kernel for randomly initialized network 
pThr = 0.01;                                                % p-value threshold of selective response 
dirIMG = 'Dataset';                                         % set data directory list of class names
dirList=dir(dirIMG); STR_LABEL = cell(1,nCLS);              %  list of class names
for ii = 1:nCLS
    STR_LABEL{ii} = dirList(ii+2).name;
end
STR_LABEL{1} = 'Face';

%% Step 1. Loading image dataset
tic
disp('Step1 : Loading image dataset ... (~ 15 sec)');
dirIMG = 'Dataset';
imd = imageDatastore(dirIMG,'IncludeSubfolders',true,'LabelSource','foldernames');         % load image dataset
imds = augmentedImageDatastore([inpSize inpSize 3],imd,'ColorPreprocessing','gray2rgb');   % resize image dataset
IMG_M = zeros(inpSize,inpSize,3,nIMG*nCLS);
for nn = 1:nIMG*nCLS
    IMG_temp  = imresize(double(imread(imd.Files{nn})), [inpSize inpSize]);
    IMG_M(:,:,:,nn) = IMG_temp;
end
toc
%% Step 2. Loading pretrained Alexnet and permute kernel of Alexnet randomly 
tic
disp('Step2: Loading pretrained Alexnet and permute kernel of Alexnet randomly ... (~ 2 sec)'); 
load('Alexnet_2018b.mat');                                                          % load pretrained Alexnet produced by Matlab 2018b
net_rand = fun_weight_permutation(net);                                             % permutation of weight kernel on each layer                                                         
Cell_net_gau = cell(1,length(stdArray));
for ii = 1:length(stdArray)
    Cell_net_gau{ii} = fun_weight_randomInit(net,stdArray(ii));                    % random initialization of weight kernel on each layer                                 
end
toc

%% Step 3. Measuring responses of neurons in the target layer
tic
disp('Step3: Measuring responses of neurons in the target layer ... (~ 20 sec)');
act = activations(net,imds,layersSet{indLayer});                                                        % response of all neurons to all images on pretrained AlexNet
act_rand = activations(net_rand,imds,layersSet{indLayer});                                              % response of all neurons to all images on permuted AlexNet

act_M = zeros(numel(act)/nIMG/nCLS,nCLS,nIMG);  
act_rand_M = zeros(numel(act_rand)/nIMG/nCLS,nCLS,nIMG);                      
for ii = 1:nCLS 
    act_M(:,ii,:) = reshape(act(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG), numel(act)/nIMG/nCLS,nIMG);     % reshape response of all neurons to all images on pretrained AlexNet
    act_rand_M(:,ii,:) = reshape(act_rand(:,:,:,(ii-1)*nIMG+1:(ii)*nIMG),numel(act)/nIMG/nCLS,nIMG);    % reshape response of all neurons to all images on permuted AlexNet
end 

act_gau_C = cell(1,length(stdArray));
for ii =1:length(stdArray)
    net_gau = Cell_net_gau{ii};                                                                         % load ramdomly intialized AlexNet with ii th standard deviation.
    act_gau = activations(net_gau,imds,layersSet{indLayer});                                            % response of all neurons to all images on ramdomly intialized AlexNet
    act_gau_M = zeros(numel(act_gau)/nIMG/nCLS,nCLS,nIMG);
    for jj = 1:nCLS
        act_gau_M(:,jj,:) = reshape(act_gau(:,:,:,(jj-1)*nIMG+1:(jj)*nIMG),numel(act)/nIMG/nCLS,nIMG);  % reshape response of all neurons to all images on permuted AlexNet
    end
    act_gau_C{ii} = act_gau_M;
end
toc
clearvars act act_rand act_gau net_gau Res_gau_mat

%% Step 4. Finding selective neuron to each class
disp('Step4: Find selective neuron to each class ... (~ 4 min)');
tic
%%% Step4-1: Find selective neuron to each class in pretrained AlexNet
[~,cellSC] = max(mean(act_M,3),[],2);                                           %find maximum respond class
cellSB = findSelCell(act_M,nCLS,cellSC,pThr,0);                                 %test whether cell is significantly selective or not

%%% Step4-2: Find selective neuron to each class in permuted AlexNet
[~,cellSC_rand] = max(mean(act_rand_M,3),[],2);                                  %find maximum respond class
cellSB_rand = findSelCell(act_rand_M,nCLS,cellSC_rand,pThr,0);                   %test whether cell is significantly selective or not 

%%% Step4-3: Find selective neuron to each class in randomly initialized AlexNet
cellSC_gau_C = cell(length(stdArray)); cellSB_gau_C = cell(length(stdArray));

for ii = 1:length(stdArray)
    act_gau_M = act_gau_C{ii};
    [~,cellSC_gau] = max(mean(act_gau_M,3),[],2);                               %find maximum respond class
    cellSB_gau = findSelCell(act_gau_M,nCLS,cellSC_gau,pThr,1);                 %test whether cell is significantly selective or not 
    cellSC_gau_C{ii} = cellSC_gau; cellSB_gau_C{ii} = cellSB_gau;
end
toc

%% Step 5. Measuring face-selectivity of each neurons
tic
disp('Step5: Measure selectivity of face selctive neurons ... (~ 1 sec)')
%%% Step5-1: Measure selectivity of face selctive neurons in permuted AlexNet
faceSI_rand = measureSI(act_rand_M,cellSB_rand,cellSC_rand,indFace,nCLS,nIMG,1);

%%% Step5-2: Measure selectivity of face selctive neurons in initialized AlexNet
faceSI_gau_C = cell(1,length(stdArray));
for ii = 1:length(stdArray)
    act_gau_M = act_gau_C{ii};
    cellSC_gau = cellSC_gau_C{ii}; 
    cellSB_gau = cellSB_gau_C{ii};
    faceSI_gau_C{ii} = measureSI(act_gau_M,cellSB_gau,cellSC_gau,indFace,nCLS,nIMG,1);
end
toc


%% Step 6. Analyzing and showing results
%% Figure 0 : Showing stimulus dataset
disp('Showing stimulus ... (~ 2 sec)')
tic
imagesPerClass = 10;
imagesInMontage = cell(imagesPerClass,nCLS);
for cc = 1:nCLS
    idx = find(double(imd.Labels) == cc);
    ind_pick = idx(randperm(length(idx),imagesPerClass));
    for ii = 1:imagesPerClass
        imagesInMontage{cc,ii} = imread(imds.Files{ind_pick(ii)}); 
    end
end
figure
montage({imagesInMontage{:}},'Size',[imagesPerClass,nCLS]);
name = STR_LABEL; set(gca,'xticklabel',name); 
toc

%% Figure 1 : Face-selectivity in pre-trained AlexNet for non-face natural image classification  
tic
disp('Figure 1 ... (~ 1 min)')
face_ind = find(cellSB'.*(cellSC==indFace));

%%% Figure 1c : Response matrix of face-selective neurons in pretrained AlexNet
actFaceCell = reshape(permute(act_M(face_ind,:,:),[3,2,1]),[nCLS*nIMG,length(face_ind)])';      % find activity of face-selective neurons
actFaceCell_norm = actFaceCell./repmat(max(actFaceCell,[],2),[1, nCLS*nIMG]);                   % Normalize response of each neuron with thier maximum response 
[~,indSort] = sort(mean(actFaceCell_norm(:,1:nIMG),2),'descend');                               % Sorting with descending order

figure('units','normalized','outerposition',[0 0 0.5 1])
subplot(2,1,1)
imagesc(actFaceCell_norm(indSort,:));
caxis([0 1]); colorbar; colormap(hot); 
xlabel('Image Index','FontSize',fontSize); ylabel('Neuron Index','FontSize',fontSize);
title('Face-selective response in pretrained AlexNet (Figure 1c)','FontSize',fontSize)

%%% Figure 1d : Average tuning curve of face-selective neurons in pretrained AlexNet 
TCface = zeros(length(face_ind),nCLS);
for cc = 1:nCLS
    TCface(:,cc) = mean(actFaceCell_norm(:,(cc-1)*nIMG+1:(cc)*nIMG),2);                         % Calculate average response for each class per neuron: tuning curve
end

subplot(2,1,2)
title('Average tuning curve of face-selective neurons in pretrained AlexNet (Figure 1d)',...
    'FontSize',fontSize) 
hold on 
for ii = 1:size(TCface,1)
    h= plot([0:nCLS+1],[mean(TCface(ii,:)) TCface(ii,:) ...
        mean(TCface(ii,:))],'Color',[0 0 0],'linewidth',1.5);                               % Plot tuning curves for each neuron
    h.Color(4)=0.01;                                                                        % Add transparency to line
end
h1 = plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) ... 
    mean(mean(TCface,1),'all')],'Color',[0.98, 0.73 0.23],'linewidth',3);
xlim([0.5 16.5]);
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);       % Plot average tuning curve
ylabel(['Normalized Response'],'FontSize',fontSize)
legend(h1,'Averaged','Location','northeast','FontSize',15)


%%% Figure 1h : Performance on the Face classification task using face-selective neurons in pretrained AlexNet
Y = imd.Labels; Label = Y == categorical(cellstr('0_Face'));            % set label: 0 = non-face, 1 = face 
N = 20; nType = 2;                                                      % set number of trial and number of classification category, here it is set 2: face vs non-face                                      

correctRat = zeros(N,nType);
for nn = 1:N
    train_act = []; train_label = [];                                   % Set training set
    test_act = []; test_label = [];                                     % Set test set
    for ii = 1:nCLS 
        actCLS = squeeze(act_M(:,ii,:))';                               % Activity of target class images
        labelCLS = Label(nIMG*(ii-1)+1:nIMG*ii);                        % label of target class images
        
        if ii == indFace                                                % set train and test samples (face class: 60 samples for train and 30 samples for test)
            perm_temp = randperm(100,90);                               % set 90 mother samples
            train_act = [train_act; actCLS(perm_temp(1:60),:)];         % pick 60 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:60),:)]; 
            test_act = [test_act; actCLS(perm_temp(61:90),:)];          % pick 30 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(61:90),:)];
        else
            perm_temp = randperm(100,6);                                % set 6 mother samples
            train_act = [train_act; actCLS(perm_temp(1:4),:)];          % pick 4 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:4),:)]; 
            test_act = [test_act; actCLS(perm_temp(5:6),:)];            % pick 2 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(5:6),:)];
        end
    end
    
    %%% Type 2 SVM : face unit only
    train_act_face = train_act(:,face_ind);                                         % training set using only face cell
    test_act_face = test_act(:,face_ind);                                           % testing set using only face cell
    Mdl = fitcecoc(train_act_face,train_label);                                     % Train SVM
    predict_label = predict(Mdl,test_act_face);                                     % Predcit test label
    correctRat(nn,1) = length(find(test_label == predict_label))...
        ./length(test_label);                                                       % Calculate correct ratio
    
    %%% Type 2 SVM : shuffled response 
    train_act_shf = train_act(randperm(numel(train_act)));                          % training set using only face cell with shuffled response
    train_act_shf = reshape(train_act_shf,[size(train_act,1),size(train_act,2)]);
    test_act_shf = test_act(randperm(numel(test_act)));                             % test set using only face cell with shuffled response
    test_act_shf = reshape(test_act_shf,[size(test_act,1),size(test_act,2)]);
    Mdl = fitcecoc(train_act_shf,train_label);                                      % Train SVM
    predict_label_shf = predict(Mdl,test_act_shf);
    correctRat(nn,2) = length(find(test_label == predict_label_shf))...
        ./length(test_label);                                                       % Calculate correct ratio
end

figure('units','normalized','outerposition',[0 0 0.5 1])
title('SVM performance of face classification task in pretrained AlexNet (Figure 1h)','FontSize',fontSize) 
hold on
bar(1,mean(correctRat(:,1)),'FaceColor',[0.98, 0.73 0.23]);
errorbar(1,mean(correctRat(:,1)),std(correctRat(:,1)),'Color','k');
bar(2,mean(correctRat(:,2)),'FaceColor',[0.98, 0.73 0.23]);
errorbar(2,mean(correctRat(:,2)),std(correctRat(:,2)),'Color','k');
name = {'','','Original response','','Response shuffled','',''}; set(gca,'xticklabel',name); %xlabel('FontSize',fontSize)
ylim([0 1]) 
ylabel('Correct ratio','FontSize',fontSize)
toc

%% Figure 2 : Face-selectivity in permuted AlexNet 
disp(['Figure 2... (~ 1 min)'])
tic
%%% Figure 2 : Face-selectivity in permuted AlexNet
% act_rand_M = Res_rand_mat;
face_SB = cellSB_rand'.*(cellSC_rand==1);
face_ind_rand = find(face_SB);

%%% Figure 2a : The untrained AlexNet by randomly permuting the weights in each convolutional layer 
layers_ind = [2,6,10,12,14]; % target layers: conv1~5
vis_N = 3; % number of filters to visualize
figure('units','normalized','outerposition',[0 0 0.5 1])
for ii = 1:length(layers_ind)
    filter_pre = net.Layers(layers_ind(ii)).Weights; ...
        sztmp = size(filter_pre,4); indtmpp=randi(sztmp, [1,vis_N]);                                        % load pre-trained filter
    filter_perm = net_rand.Layers(layers_ind(ii)).Weights; ...
        sztmp_r = size(filter_perm,4); indtmpp_r=randi(sztmp_r, [1,vis_N]);                                 % load permutedre filter
    for jj = 1:length(indtmpp)
        ax=subplot(5,7,7*(ii-1)+jj);
        tmp = squeeze(filter_pre(:,:,1,indtmpp(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_pre(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])    % plot pre-trained filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',15); end
        ax=subplot(5,7,7*(ii-1)+jj+4);
        tmp = squeeze(filter_perm(:,:,1,indtmpp_r(jj))); caxtmp = max(abs(min(tmp(:))), abs(max(tmp(:))));
        imagesc(squeeze(filter_perm(:,:,1,indtmpp(jj)))); axis image off; %caxis(ax, [-2*caxtmp 2*caxtmp])   % plot permutedre filter
        if jj == 2; title(['Example Conv',num2str(ii),' filters'],'FontSize',15); end
    end
end
sgtitle('Left: pretrained AlexNet, Right: permuted AlexNet','FontSize',fontSize);
colormap(gray)

%%% Figure 2b: Response matrix of face-selective neurons in permuted AlexNet
actFaceCell = reshape(permute(act_rand_M(face_ind_rand,:,:),[3,2,1]),...
    [nCLS*nIMG,length(face_ind_rand)])';                                            % find activity of face-selective neurons
actFaceCell_norm = actFaceCell./repmat(max(actFaceCell,[],2),[1, nCLS*nIMG]);       % Normalize response of each neuron with thier maximum response 
[~,indSort] = sort(mean(actFaceCell_norm(:,1:nIMG),2),'descend');                   % Sorting with descending order

figure('units','normalized','outerposition',[0 0 0.5 1]); subplot(2,1,1)
imagesc(actFaceCell_norm(indSort,:));
caxis([0 1]); colorbar; colormap(hot); 
xlabel('Image Index','FontSize',fontSize); ylabel('Neuron Index','FontSize',fontSize);
title('Face-selective response in permuted AlexNet','FontSize',fontSize)

%%% Figure 2b : Average tuning curve of face-selective neurons in permuted AlexNet 
TCface = zeros(length(face_ind_rand),nCLS);
for cc = 1:nCLS
    TCface(:,cc) = mean(actFaceCell_norm(:,(cc-1)*nIMG+1:(cc)*nIMG),2);                      % Calculate average response for each class per neuron: tuning curve
end

subplot(2,1,2); hold on 
for ii = 1:size(TCface,1)
    h= plot([0:nCLS+1],[mean(TCface(ii,:)) TCface(ii,:) ...
        mean(TCface(ii,:))],'Color',[0 0 0],'linewidth',1.5);                               % Plot tuning curves for each neuron
    h.Color(4)=0.01;                                                                        % Add transparency to line
end
h1 = plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) ... 
    mean(mean(TCface,1),'all')],'Color',[0.98, 0.73 0.23],'linewidth',3);
xlim([0.5 16.5]);
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);       % Plot average tuning curve
ylabel(['Normalized Response'],'FontSize',fontSize)
legend(h1,'Averaged','Location','northeast','FontSize',15)
title('Average tuning curve of face-selective neurons in pretrained AlexNet (Figure 1d)',...
    'FontSize',fontSize) 


%%% Figure 2f-g 
%%% i) preferred feature image : Face, No selectivity
[~,ind_SI_sort] = sort(faceSI_rand,'descend');                 % sort face selectivity
trg_idx = 3; cell_list = face_ind_rand(ind_SI_sort(trg_idx));   % get strongly selective cell to face
SB_list = find(cellSB_rand); NSB_list = find(~cellSB_rand);
[~,ind_maxres] = max(mean(mean(act_rand_M(NSB_list,:,:),2),3));
cell_list = [cell_list NSB_list(ind_maxres)];                   % get not selective cell to face with stronges activity amplitude
Cell_RF = prefFeatureIMG(act_rand_M,inpSize,IMG_M,cell_list);   % get preferred feature images

figure                                                          % plot preferred feature images
for ii = 1:length(cell_list)
    subplot(1,length(cell_list),ii);
    imshow(uint8(Cell_RF{ii}));
    if ii == 1; title('Face'); else title('No selectivity'); end
end

%%% ii) preferred feature images with various selectivity indices
trg_idx = [3, 83, 163, 325, 406];
cell_list = face_ind_rand(ind_SI_sort(trg_idx));                    % get face selective cell in descending order of face selectivity
Cell_RF_SI = prefFeatureIMG(act_rand_M,inpSize,IMG_M,cell_list);    % get preferred feature images

figure                                                              % plot preferred feature images
for ii = 1:length(cell_list)
    subplot(1,5,ii)
    imshow(uint8(Cell_RF_SI{ii})); title(['Rank ',num2str(trg_idx(ii))]);
end

%%% Figure 2h : Performance on the Face classification task using face-selective neurons in permuted AlexNet
Y = imd.Labels; Label = Y == categorical(cellstr('0_Face'));
N = 30; nType = 2;                                          % set number of trial and number of classification category, here it is set 2: face vs non-face                                      
nCellList = logspace(log10(1/length(face_ind_rand)),0,20);  % set list of number of cell using for SVM training
correctRat = zeros(N,length(nCellList),nType);
for nn = 1:N
    train_act = []; train_label = [];                                   % Set training set
    test_act = []; test_label = [];                                     % Set test set
    for ii = 1:nCLS
        actCLS = transpose(squeeze(act_rand_M(:,ii,:)));
        labelCLS = Label(nIMG*(ii-1)+1:nIMG*ii);
        
        if ii == indFace                                                % set train and test samples (face class: 60 samples for train and 30 samples for test)
            perm_temp = randperm(100,90);                               % set 90 mother samples
            train_act = [train_act; actCLS(perm_temp(1:60),:)];         % pick 60 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:60),:)]; 
            test_act = [test_act; actCLS(perm_temp(61:90),:)];          % pick 30 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(61:90),:)];
        else
            perm_temp = randperm(100,6);                                % set 6 mother samples
            train_act = [train_act; actCLS(perm_temp(1:4),:)];          % pick 4 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:4),:)]; 
            test_act = [test_act; actCLS(perm_temp(5:6),:)];            % pick 2 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(5:6),:)];
        end
    end
       
    for p = 1:length(nCellList)

        %%% Type 1 SVM : face neurons
        ind_perm = randperm(length(face_ind_rand),...
            round(length(face_ind_rand)*nCellList(p)));                     % pick random face-selective cell with different number
        train_act_face = train_act(:,face_ind_rand(ind_perm));              % training set using only face cell
        test_act_face = test_act(:,face_ind_rand(ind_perm));                % testing set using only face cell
        Mdl = fitcecoc(train_act_face,train_label);                         % Train SVM
        predict_label = predict(Mdl,test_act_face);                         % Predcit test label
        correctRat(nn,p,1) = length(find(test_label == predict_label))...
        ./length(test_label);                                               % Calculate correct ratio
    
        %%% Type 2 SVM : non-selective neurons
        ind_perm = randperm(length(NSB_list),round(length(face_ind_rand)*nCellList(p))); 
        train_act_noSel = train_act(:,NSB_list(ind_perm));                  % training set using only no-selectivity cell
        test_act_noSel = test_act(:,NSB_list(ind_perm));                    % testing set using only no-selectivity cell
        Mdl = fitcecoc(train_act_noSel,train_label);                            % Train SVM
        predict_label = predict(Mdl,test_act_noSel);                        % Predcit test label
        correctRat(nn,p,2) = length(find(test_label == predict_label))...
        ./length(test_label);                                               % Calculate correct ratio
    end
end

figure('units','normalized','outerposition',[0 0 0.5 1])
hold on
shadedErrorBar(nCellList.*100,mean(correctRat(:,:,1),1),std(correctRat(:,:,1),1),'lineprops',{'r','markerfacecolor','r'});
shadedErrorBar(nCellList.*100,mean(correctRat(:,:,2),1),std(correctRat(:,:,2),1),'lineprops',{'k','markerfacecolor','k'});
h1 = plot(nCellList.*100,mean(correctRat(:,:,1),1),'r','linewidth',3);
h2 = plot(nCellList.*100,mean(correctRat(:,:,2),1),'k','linewidth',3);
xlim([0 100])
ylim([0.49 1.01])
set(gca, 'XScale', 'log')
xlabel('Neurons considered (%)','FontSize',fontSize)
ylabel('Correct ratio','FontSize',fontSize)
title('SVM performance of face classification task in permuted AlexNet (Figure 2h)','FontSize',fontSize) 
legend([h1 h2],'Face-selective neurons','Neurons with no selectivity','Location','southeast','FontSize',15)
toc

%% Figure 3 : View-point invariant characteristics of face-selective neurons
disp(['Figure 3...'])
tic
%%% View-point invariant characteristics of face-selective neurons
% tuning curve (sin / max ���߱�)

dir_img_view = 'View_dataset';
imd_view = imageDatastore(dir_img_view,'IncludeSubfolders',true,'LabelSource','foldernames');               % load image dataset
imds_view = augmentedImageDatastore([inpSize inpSize 3],imd_view,'ColorPreprocessing','gray2rgb');          % resize image dataset
array_ViewClass = imd_view.Labels;

nCLS_view = 5; nIMG_vew = 10;

act_rand_C = cell(1,3); act_rand_C{3} = act_rand_M;         % activity in each layer (3,4,5)
cellSB_rand_C = cell(1,3); cellSB_rand_C{3} = cellSB_rand;  % cell for object selective cells in each layer (3,4,5)
cellSC_rand_C = cell(1,3); cellSC_rand_C{3} = cellSC_rand;  % cell for selective class of each cell in each layer (3,4,5)
faceSI_rand_C = cell(1,3); faceSI_rand_C{3} = faceSI_rand;  % selectivity index face-selective cell in each layer (3,4,5)

act_view_rand_C = cell(1,3);                                % activity for view-point stimulus in each layer (3,4,5)
cellVB_rand_C = cell(1,3);                                  % cell for view-point invariant cells in each layer (3,4,5)
cellVI_rand_C = cell(1,3);                                  % view-point invariant index of face-selective cells in each layer (3,4,5)

for ll = 3:length(layersSet)
    disp(['layer : ',num2str(ll)])
    % finding face-selective neuron in conv3-4
    if ll ~= length(layersSet)
        act_rand_ll = activations(net_rand,imds,layersSet{ll});                 % response of all neurons to all images on pretrained AlexNet layer ll
        act_rand_ll_M = zeros(numel(act_rand_ll)/nIMG/nCLS,nCLS,nIMG);
        for ii = 1:nCLS
            act_rand_ll_M(:,ii,:) = reshape(act_rand_ll(:,:,:,(ii-1)...         % reshape response of all neurons to all images on pretrained AlexNet layer ll
                *nIMG+1:(ii)*nIMG), numel(act_rand_ll)/nIMG/nCLS,nIMG);
        end
        act_rand_C{ll-2} = act_rand_ll_M;
        
        [~,cellSC_rand_ll] = max(mean(act_rand_ll_M,3),[],2);                   % find maximum respond class
        cellSB_rand_ll = findSelCell(act_rand_ll_M,nCLS,cellSC_rand_ll,pThr,0); % test whether cell is significantly selective or not
        faceSI_rand_ll = measureSI(act_rand_ll_M,cellSB_rand_ll,...
            cellSC_rand_ll,indFace,nCLS,nIMG,1);                                % calculate selectivity index for face-selecive cells
        cellSB_rand_C{ll-2} = cellSB_rand_ll; cellSC_rand_C{ll-2} = cellSC_rand_ll; faceSI_rand_C{ll-2} = faceSI_rand_ll;
    end
    
    tic
    % finding viewpoint invariant face neuron in conv3-5
    act_view_rand_ll = activations(net_rand,imds_view,layersSet{ll});           % response of all neurons to all images on pretrained AlexNet layer ll
    act_view_rand_ll_M = zeros(numel(act_view_rand_ll)/nIMG_vew/nCLS_view,nCLS_view,nIMG_vew);
    for ii = 1:nCLS_view
        act_view_rand_ll_M(:,ii,:) = reshape(act_view_rand_ll(:,:,:,(ii-1)*nIMG_vew+1:(ii)*nIMG_vew)...
            , numel(act_view_rand_ll)/nIMG_vew/nCLS_view,nIMG_vew); % reshape response of all neurons to all images on pretrained AlexNet layer ll
    end
    act_view_rand_C{ll-2} = act_view_rand_ll_M;
    
    array_selView_unitIdx_rand = zeros(1,size(act_view_rand_ll_M,1));
    array_VII = zeros(1,size(act_view_rand_ll_M,1)); 
    for nn = 1:size(act_view_rand_ll_M,1)
        data = squeeze(act_view_rand_ll_M(nn,:,:));
        data_res = [];
        for ii = 1:length(dir(dir_img_view))-2
            data_res = [data_res; data(ii,:)'];
        end
        array_selView_unitIdx_rand(nn) = anova1(data_res,array_ViewClass,'off');
        array_VII(nn) = std(mean(squeeze(act_view_rand_ll_M(nn,:,:)),2));
    end
    array_selView_unitIdx_rand(find(isnan(array_selView_unitIdx_rand))) = 0;
    Result_facesel_view_idx_rand = (array_selView_unitIdx_rand > pThr)&logical(cellSB_rand_C{ll-2});
    
    cellVB_rand_C{ll-2} = Result_facesel_view_idx_rand;
    cellVI_rand_C{ll-2} = 1./array_VII;
    toc
end

%%% Figure 0 : Showing stimulus dataset
imagesPerClass = 10;
imagesInMontage = cell(nCLS_view,imagesPerClass);
for c = 1:nCLS_view
    idx = find(double(imd_view.Labels) == c);
    ind_pick = idx(randperm(length(idx),imagesPerClass));
    for i = 1:imagesPerClass
        imagesInMontage{i,c} = ...
        imresize(imread(imd_view.Files{ind_pick(i)}),[inpSize,inpSize]); 
    end
end
figure
a = montage({imagesInMontage{:}},'Size',[nCLS_view,imagesPerClass]);
name = STR_LABEL; set(gca,'xticklabel',name); 

%%% Figure 3c-d : 
%%% i) View-invariant and view-specific response of face-selective neurons
%%% ii) Average tuning curves of face-selective neurons in each layer
Cell_tuning_curve = cell(1,3);
for ll = 3:5
    DATA_face_view = act_view_rand_C{ll-2};
    Map_res_faceView = zeros(size(DATA_face_view,1),nCLS_view*nIMG_vew);
    for ii = 1:size(DATA_face_view,1)
        Map_res_faceView(ii,:) = reshape(squeeze(DATA_face_view(ii,:,:)),1,nCLS_view*nIMG_vew);
    end
    Norm_Map_res_faceView = Map_res_faceView./max(Map_res_faceView,[],1);
%     Norm_Map_res_faceView = Map_res_faceView./max(Map_res_faceView,[],'all');
    Norm_Map_res_faceView(isnan(Norm_Map_res_faceView)) = 0;
    
    ind_face_perm = find(cellSB_rand_C{ll-2});
    array_tuning_curve = zeros(length(ind_face_perm),nCLS_view);
    for jj = 1:length(ind_face_perm)
        for cc = 1:nCLS_view
            array_tuning_curve(jj,cc) = mean(Norm_Map_res_faceView(ind_face_perm(jj),(cc-1)*10+1:cc*10),2);
        end
    end
    
    Cell_tuning_curve{ll-2} = array_tuning_curve;
end

Cell_tuning_curve_align = cell(1,3);
array_L3 = []; array_L4 = []; array_L5 = [];

for ll = 3:5
    ind_face_perm = find(cellSB_rand_C{ll-2});
    array_align = zeros(length(ind_face_perm),9);
    tuning_curve = Cell_tuning_curve{ll-2};
    for ii = 1:5
        for jj = 1:5
            array_align(:,jj-ii+5) = array_align(:,jj-ii+5)+tuning_curve(:,jj);
        end
    end
    Cell_tuning_curve_align{ll-2} = array_align;
end


max_conv3 = max(mean(Cell_tuning_curve_align{1},1));
max_conv4 = max(mean(Cell_tuning_curve_align{2},1));
max_conv5 = max(mean(Cell_tuning_curve_align{3},1));

figure
set(gcf,'Position',[400 400 300 300])
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{1},1)+max_conv4-max_conv3,std(Cell_tuning_curve_align{1},1),'lineprops',{'k','markerfacecolor','k','linewidth',1.5})
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{2},1),std(Cell_tuning_curve_align{2},1),'lineprops',{'b','markerfacecolor','b','linewidth',1.5})
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{3},1)+max_conv4-max_conv5,std(Cell_tuning_curve_align{3},1),'lineprops',{'r','markerfacecolor','r','linewidth',1.5})
xlim([-180 180])

figure
hold on
set(gcf,'Position',[400 400 300 300])
plot([-180:45:180],mean(Cell_tuning_curve_align{1},1)+max_conv4-max_conv3,'k','linewidth',3)
plot([-180:45:180],mean(Cell_tuning_curve_align{2},1),'b','linewidth',3)
plot([-180:45:180],mean(Cell_tuning_curve_align{3},1)+max_conv4-max_conv5,'r','linewidth',3)
xlim([-180 180])
xlabel('Angle difference (deg)','FontSize',10); ylabel('Normalized response (A.U.)','FontSize',10); xlim([-180 180]); xticks([-180 -90 0 90 180])

%%% Figure 3e : Invariance index over layer in permuted AlexNet
Cell_VII = cell(1,3);
thr_VII = 10;
mean_VII = zeros(1,3); std_VII = zeros(1,3);
for ll = 3:5
    ind_face_perm = find(cellSB_rand_C{ll-2});
    temp_VII = cellVI_rand_C{ll-2};
    temp_VII = temp_VII(ind_face_perm);
    temp_VII(temp_VII>thr_VII) = [];
    mean_VII(ll-2) = mean(temp_VII);
    std_VII(ll-2) = std(temp_VII);
end

figure
hold on
set(gcf,'Position',[400 400 300 300])
errorbar([1:3],mean_VII(1:3),std_VII(1:3),'-ko','linewidth',2)
xlim([0.5 3.5])
% ylim([0 20])
ylabel('Invariance index','FontSize',10); xlim([0.5 3.5]); xticks([1 2 3])
name = {'Conv3','Conv4','Conv5'}; set(gca,'xticklabel',name);


%%% Figure 3i : Receptive fields over layer in permuted AlexNet
% backtracking matrix 
Cell_RF_layer = cell(1,3); Cell_array_idx = cell(1,3); numSampleRF = 6;
array_sz = [55 55 96; 27 27 256; 13 13 384; 13 13 384; 13 13 256];
for ll = 3:5
    act_rand_ll_M = act_rand_C{ll-2};
    
    SI = faceSI_rand_C{ll-2}; [SI_sort,ind_SI_sort] = sort(SI,'descend');
    
    Cell_selective_idx_perm = cellSB_rand_C{ll-2};
    sel_class_perm = cellSC_rand_C{ll-2};
    ind_rand_rf = find(Cell_selective_idx_perm'.*(sel_class_perm==1));
    temp_idx = [1:200];
    
    cell_ind_list = ind_rand_rf(ind_SI_sort(temp_idx));
    [i1,i2,i3] = ind2sub(array_sz(ll,:),cell_ind_list);
    ind_temp = find(((i1<9)&(i1>4))&((i2<9)&(i2>4)));
    cell_ind_list = cell_ind_list(ind_temp); 
    cell_ind_list = cell_ind_list(1:numSampleRF);
    cell_ind_list = cell_ind_list(randperm(length(cell_ind_list),numSampleRF));
    
    tic
    Cell_RF_layer{ll-2} = prefFeatureIMG(act_rand_ll_M,inpSize,IMG_M,cell_ind_list);
    
    toc
    Cell_array_idx{ll-2} = cell_ind_list;
end

array_fig_pos = [1,2,7,8,13,14; 3,4,9,10,15,16; 5,6,11,12,17,18];
figure
for ll = 3:5
    switch ll
        case 3 
           load('conv3_CRF_allXY.mat')
        case 4 
            load('conv4_CRF_allXY.mat')
        case 5
            load('conv5_CRF_allXY.mat')
    end
    indLayer = ll;
    
    cell_ind_list = Cell_array_idx{ll-2}; RF = Cell_RF_layer{ll-2};
    temp_pos = array_fig_pos(ll-2,:);
    for ii = 1:length(cell_ind_list)
        [row,col,chan] = ind2sub(array_sz(ll,:),cell_ind_list(ii));
        temp_ind = sub2ind(array_sz(ll,:),row,col,1);
        RF_face = RF{ii};
        
        Mask = double(Cell_CRF2{find(ind_all_XY == temp_ind)});
        Mask2 = repmat(Mask,[1,1,3]);
        
        subplot(3,6,temp_pos(ii))
        b = imshow(uint8(RF_face.*Mask2)); axis off; axis image
        if ii == 1
            title(['Conv',num2str(ll)])
        end
    end
end
toc
% 

%% Figure 4 : Face-selectivity induced by variation in convolutional weights
disp(['Figure 4...'])
tic
%%% Figure 4a The untrained AlexNet by randomly permuting the weights in each convolutional layer (Figure 4a)
layers_ind = [2,6,10,12,14]; 
edgesh = -0.15:0.005:0.15; % bin edges of weight distribution
wrange = -0.15:0.0005:0.15; % range of weights
array_color = [0 1 1; 0 0.8 0.8; 0 0.8 0.2];

figure('units','normalized','outerposition',[0 0 0.5 1])
weight_tot = [];
for ind_tl = 1:length(layers_ind)
    targetlayer_ind = layers_ind(ind_tl);
    weight_conv = net.Layers(targetlayer_ind ,1).Weights;
    bias_conv = net.Layers(targetlayer_ind ,1).Bias;
    weight_tot = [weight_tot;weight_conv(:)];
end

subplot(6,4,[1 2 5 6])
hold on 
histogram(weight_tot(:),edgesh, 'Normalization', 'probability','FaceColor',[0.5 0.5 0.5])
% set(gcf,'Position',[100 100 1000 400])
xlabel('Weight','FontSize',15); ylabel('Ratio','FontSize',15); ylim([0 0.2]); yticks([0 0.1 0.2]); xlim([-0.08 0.08]); xticks([-0.08 0 0.08])

  

% Visualizing example filter    
for ii = 1:length(Cell_net_gau)
    if ii==1
        nettmp = net;
    else
        nettmp = Cell_net_gau{ii};
    end
    
    tmp = nettmp.Layers(layers_ind(1)).Weights;sztmp = size(tmp,4); indtmpp=randi(sztmp, [1,3]);
    for jj = 1:length(indtmpp)
        tmp2 = squeeze(tmp(:,:,1,indtmpp(jj)));
        if ii==0 && face_ind ==1
            caxtmp = max(abs(min(tmp2(:))), abs(max(tmp2(:))));
        end

        subplot(6,4,4*(jj-1)+12+ii); imagesc(squeeze(tmp(:,:,1,indtmpp(jj)))); axis image off; caxis([-2*caxtmp 2*caxtmp])
        if ii~=1
            if jj ==1;title(['Weight variation = ' num2str(100-20*(ii-1)) '%'],'FontSize',10);end
        else
            if jj ==1;title(['Pretrained'],'FontSize',10);end
        end
    end
    colormap(gray);
end

%%% Figure 4b : Average of all tuning curves for face-selective neurons across different levels of weight variation
array_color = [0 1 1; 0 0.8 0.8; 0 0.8 0.2];
figure('units','normalized','outerposition',[0 0 0.5 1])
hold on
for ii = 2:length(stdArray)
    act_gau_M = act_gau_C{ii};
    cellSB_gau = cellSB_gau_C{ii};
    cellSC_gau = cellSC_gau_C{ii};
    ind_temp = cellSB_gau'.*(cellSC_gau==1);
    ind_gau = find(ind_temp);
    
    Map_res_face = zeros(nCLS*nIMG,length(ind_temp));
    array_init_ind = [0:100:1500];
    for jj = 1:length(ind_temp)
        for cc = 1:nCLS
            Map_res_face(array_init_ind(cc)+1:array_init_ind(cc)+100,jj) = squeeze(act_gau_M(jj,cc,:));
        end
    end
    
    TCface = zeros(length(ind_gau),nCLS);
    for cc = 1:nCLS
        tempDATA_res = transpose(squeeze(act_gau_M(:,cc,:)));
%         tempDATA_face = tempDATA_res./max(Map_res_face,[],1);
        tempDATA_face = tempDATA_res;
        TCface(:,cc) = mean(tempDATA_face(:,ind_gau),1);
    end
    
    plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) mean(mean(TCface,1),'all')],'Color',array_color(ii-1,:),'linewidth',3);
end
xlim([0.5 16.5]); %ylim([0 mean(array_face_tuning(:,1),1)+std(array_face_tuning(:,1),1)])
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);
ylabel(['Averaged response'],'FontSize',fontSize)
title('Averaged tuning curves for face-selective neurons across different levels of weight variation (Figure 4b)','FontSize',fontSize) 
legend('weight variation = 60%','weight variation = 80%','weight variation = 100%','FontSize',15)

tic
Cell_RF_w = cell(1,length(stdArray));
temp_idx = [5 4 3 2];
for ii = 1:length(stdArray)
    act_gau_M = act_gau_C{ii};
    cellSB_gau = cellSB_gau_C{ii};
    cellSC_gau = cellSC_gau_C{ii};
    ind_temp = cellSB_gau'.*(cellSC_gau==1);
    ind_gau = find(ind_temp);
    
    SI_list_face_gau = faceSI_gau_C{ii};
    [SI_sort,ind_SI_sort] = sort(SI_list_face_gau,'descend');
    cell_ind_list = ind_gau(ind_SI_sort(temp_idx(ii)));
    Cell_RF_w{ii} = prefFeatureIMG(act_gau_M,inpSize,IMG_M,cell_ind_list);
end
toc


figure
for ii = 1:length(stdArray)
    
    subplot(1,length(stdArray),ii)
    a = Cell_RF_w{ii};
    imshow(uint8(a{1}));
    title(['Weight variation : ',num2str(stdArray(ii)*100),' %'])
end

toc