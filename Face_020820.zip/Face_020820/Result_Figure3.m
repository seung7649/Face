%% Figure 3 : View-point invariant characteristics of face-selective neurons
fontSize_title = 15; 
fontSize_label = 15; 
fontSize_legend = 12; 

tic
%%% View-point invariant characteristics of face-selective neurons
% tuning curve (sin / max ���߱�)

dir_img_view = 'View_dataset';
imd_view = imageDatastore(dir_img_view,'IncludeSubfolders',true,'LabelSource','foldernames');               % load image dataset
imds_view = augmentedImageDatastore([inpSize inpSize 3],imd_view,'ColorPreprocessing','gray2rgb');          % resize image dataset
array_ViewClass = imd_view.Labels;

nCLS_view = 5; nIMG_vew = 10;

act_rand_C = cell(1,3); act_rand_C{3} = act_rand_M;         % activity in each layer (3,4,5)
cellSB_rand_C = cell(1,3); cellSB_rand_C{3} = cellSB_rand;  % cell for object selective cells in each layer (3,4,5)
cellSC_rand_C = cell(1,3); cellSC_rand_C{3} = cellSC_rand;  % cell for selective class of each cell in each layer (3,4,5)
faceSI_rand_C = cell(1,3); faceSI_rand_C{3} = faceSI_rand;  % selectivity index face-selective cell in each layer (3,4,5)

act_view_rand_C = cell(1,3);                                % activity for view-point stimulus in each layer (3,4,5)
cellVB_rand_C = cell(1,3);                                  % cell for view-point invariant cells in each layer (3,4,5)
cellVI_rand_C = cell(1,3);                                  % view-point invariant index of face-selective cells in each layer (3,4,5)

for ll = 3:length(layersSet)
    disp(['layer : ',num2str(ll)])
    % finding face-selective neuron in conv3-4
    if ll ~= length(layersSet)
        act_rand_ll = activations(net_rand,imds,layersSet{ll});                 % response of all neurons to all images on pretrained AlexNet layer ll
        act_rand_ll_M = zeros(numel(act_rand_ll)/nIMG/nCLS,nCLS,nIMG);
        for ii = 1:nCLS
            act_rand_ll_M(:,ii,:) = reshape(act_rand_ll(:,:,:,(ii-1)...         % reshape response of all neurons to all images on pretrained AlexNet layer ll
                *nIMG+1:(ii)*nIMG), numel(act_rand_ll)/nIMG/nCLS,nIMG);
        end
        act_rand_C{ll-2} = act_rand_ll_M;
        
        [~,cellSC_rand_ll] = max(mean(act_rand_ll_M,3),[],2);                   % find maximum respond class
        cellSB_rand_ll = findSelCell(act_rand_ll_M,nCLS,cellSC_rand_ll,pThr,0); % test whether cell is significantly selective or not
        faceSI_rand_ll = measureSI(act_rand_ll_M,cellSB_rand_ll,...
            cellSC_rand_ll,indFace,nCLS,nIMG,1);                                % calculate selectivity index for face-selecive cells
        cellSB_rand_C{ll-2} = cellSB_rand_ll; cellSC_rand_C{ll-2} = cellSC_rand_ll; faceSI_rand_C{ll-2} = faceSI_rand_ll;
    end
    
    tic
    % finding viewpoint invariant face neuron in conv3-5
    act_view_rand_ll = activations(net_rand,imds_view,layersSet{ll});           % response of all neurons to all images on pretrained AlexNet layer ll
    act_view_rand_ll_M = zeros(numel(act_view_rand_ll)/nIMG_vew/nCLS_view,nCLS_view,nIMG_vew);
    for ii = 1:nCLS_view
        act_view_rand_ll_M(:,ii,:) = reshape(act_view_rand_ll(:,:,:,(ii-1)*nIMG_vew+1:(ii)*nIMG_vew)...
            , numel(act_view_rand_ll)/nIMG_vew/nCLS_view,nIMG_vew); % reshape response of all neurons to all images on pretrained AlexNet layer ll
    end
    act_view_rand_C{ll-2} = act_view_rand_ll_M;
    
    array_selView_unitIdx_rand = zeros(1,size(act_view_rand_ll_M,1));
    array_VII = zeros(1,size(act_view_rand_ll_M,1)); 
    for nn = 1:size(act_view_rand_ll_M,1)
        data = squeeze(act_view_rand_ll_M(nn,:,:));
        data_res = [];
        for ii = 1:length(dir(dir_img_view))-2
            data_res = [data_res; data(ii,:)'];
        end
        array_selView_unitIdx_rand(nn) = anova1(data_res,array_ViewClass,'off');
        array_VII(nn) = std(mean(squeeze(act_view_rand_ll_M(nn,:,:)),2));
    end
    array_selView_unitIdx_rand(find(isnan(array_selView_unitIdx_rand))) = 0;
    Result_facesel_view_idx_rand = (array_selView_unitIdx_rand > pThr)&logical(cellSB_rand_C{ll-2});
    
    cellVB_rand_C{ll-2} = Result_facesel_view_idx_rand;
    cellVI_rand_C{ll-2} = 1./array_VII;
    toc
end

%%% Figure 0 : Showing stimulus dataset
imagesPerClass = 10;
imagesInMontage = cell(nCLS_view,imagesPerClass);
for c = 1:nCLS_view
    idx = find(double(imd_view.Labels) == c);
    ind_pick = idx(randperm(length(idx),imagesPerClass));
    for i = 1:imagesPerClass
        imagesInMontage{i,c} = ...
        imresize(imread(imd_view.Files{ind_pick(i)}),[inpSize,inpSize]); 
    end
end
figure
a = montage({imagesInMontage{:}},'Size',[nCLS_view,imagesPerClass]);
name = STR_LABEL; set(gca,'xticklabel',name); 

%%% Figure 3c-d : 
%%% i) View-invariant and view-specific response of face-selective neurons
%%% ii) Average tuning curves of face-selective neurons in each layer
Cell_tuning_curve = cell(1,3);
for ll = 3:5
    DATA_face_view = act_view_rand_C{ll-2};
    Map_res_faceView = zeros(size(DATA_face_view,1),nCLS_view*nIMG_vew);
    for ii = 1:size(DATA_face_view,1)
        Map_res_faceView(ii,:) = reshape(squeeze(DATA_face_view(ii,:,:)),1,nCLS_view*nIMG_vew);
    end
    Norm_Map_res_faceView = Map_res_faceView./max(Map_res_faceView,[],1);
%     Norm_Map_res_faceView = Map_res_faceView./max(Map_res_faceView,[],'all');
    Norm_Map_res_faceView(isnan(Norm_Map_res_faceView)) = 0;
    
    ind_face_perm = find(cellSB_rand_C{ll-2});
    array_tuning_curve = zeros(length(ind_face_perm),nCLS_view);
    for jj = 1:length(ind_face_perm)
        for cc = 1:nCLS_view
            array_tuning_curve(jj,cc) = mean(Norm_Map_res_faceView(ind_face_perm(jj),(cc-1)*10+1:cc*10),2);
        end
    end
    
    Cell_tuning_curve{ll-2} = array_tuning_curve;
end

Cell_tuning_curve_align = cell(1,3);
array_L3 = []; array_L4 = []; array_L5 = [];

for ll = 3:5
    ind_face_perm = find(cellSB_rand_C{ll-2});
    array_align = zeros(length(ind_face_perm),9);
    tuning_curve = Cell_tuning_curve{ll-2};
    for ii = 1:5
        for jj = 1:5
            array_align(:,jj-ii+5) = array_align(:,jj-ii+5)+tuning_curve(:,jj);
        end
    end
    Cell_tuning_curve_align{ll-2} = array_align;
end


max_conv3 = max(mean(Cell_tuning_curve_align{1},1));
max_conv4 = max(mean(Cell_tuning_curve_align{2},1));
max_conv5 = max(mean(Cell_tuning_curve_align{3},1));

figure('units','normalized','outerposition',[0 0 0.5 0.5])
hold on 
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{1},1)+max_conv4-max_conv3,std(Cell_tuning_curve_align{1},1),'lineprops',{'k','markerfacecolor','k','linewidth',1.5})
h1 = plot([-180:45:180],mean(Cell_tuning_curve_align{1},1)+max_conv4-max_conv3,'k','linewidth',3);
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{2},1),std(Cell_tuning_curve_align{2},1),'lineprops',{'b','markerfacecolor','b','linewidth',1.5})
h2 = plot([-180:45:180],mean(Cell_tuning_curve_align{2},1),'b','linewidth',3);
shadedErrorBar([-180:45:180],mean(Cell_tuning_curve_align{3},1)+max_conv4-max_conv5,std(Cell_tuning_curve_align{3},1),'lineprops',{'r','markerfacecolor','r','linewidth',1.5})
h3 = plot([-180:45:180],mean(Cell_tuning_curve_align{3},1)+max_conv4-max_conv5,'r','linewidth',3);
xlim([-180 180]); xticks([-180 -90 0 90 180])
xlabel('Angle difference (deg)','FontSize',fontSize_label); ylabel('Normalized response (A.U.)','FontSize',fontSize_label)
title(['Average tuning curves of face-selective neurons in each layer (Figure 3b)'],'FontSize',fontSize_title);  
legend([h1 h2 h3],'Conv3','Conv4','Conv5','Location','southeast','FontSize',fontSize_legend) 

%%% Figure 3e : Invariance index over layer in permuted AlexNet
Cell_VII = cell(1,3);
thr_VII = 10;
mean_VII = zeros(1,3); std_VII = zeros(1,3);
for ll = 3:5
    ind_face_perm = find(cellSB_rand_C{ll-2});
    temp_VII = cellVI_rand_C{ll-2};
    temp_VII = temp_VII(ind_face_perm);
    temp_VII(temp_VII>thr_VII) = [];
    mean_VII(ll-2) = mean(temp_VII);
    std_VII(ll-2) = std(temp_VII);
end

figure('units','normalized','outerposition',[0 0 0.5 0.5])
hold on
errorbar([1:3],mean_VII(1:3),std_VII(1:3),'-ko','linewidth',2)
xlim([0.5 3.5])
% ylim([0 20])
ylabel('Invariance index','FontSize',fontSize_label); xlim([0.5 3.5]); xticks([1 2 3])
name = {'Conv3','Conv4','Conv5'}; set(gca,'xticklabel',name,'FontSize',fontSize_label);
title(['invariance index over layer in permuted AlexNet  (Figure 3e)'],'FontSize',fontSize_title);  


%%% Figure 3i : Receptive fields over layer in permuted AlexNet
% backtracking matrix 
Cell_RF_layer = cell(1,3); Cell_array_idx = cell(1,3); numSampleRF = 6;
array_sz = [55 55 96; 27 27 256; 13 13 384; 13 13 384; 13 13 256];
for ll = 3:5
    act_rand_ll_M = act_rand_C{ll-2};
    
    SI = faceSI_rand_C{ll-2}; [SI_sort,ind_SI_sort] = sort(SI,'descend');
    
    Cell_selective_idx_perm = cellSB_rand_C{ll-2};
    sel_class_perm = cellSC_rand_C{ll-2};
    ind_rand_rf = find(Cell_selective_idx_perm'.*(sel_class_perm==1));
    temp_idx = [1:200];
    
    cell_ind_list = ind_rand_rf(ind_SI_sort(temp_idx));
    [i1,i2,i3] = ind2sub(array_sz(ll,:),cell_ind_list);
    ind_temp = find(((i1<9)&(i1>4))&((i2<9)&(i2>4)));
    cell_ind_list = cell_ind_list(ind_temp); 
    cell_ind_list = cell_ind_list(1:numSampleRF);
    cell_ind_list = cell_ind_list(randperm(length(cell_ind_list),numSampleRF));
    
    tic
    Cell_RF_layer{ll-2} = prefFeatureIMG(act_rand_ll_M,inpSize,IMG_M,cell_ind_list);
    
    toc
    Cell_array_idx{ll-2} = cell_ind_list;
end

array_fig_pos = [1,2,7,8,13,14; 3,4,9,10,15,16; 5,6,11,12,17,18];
figure('units','normalized','outerposition',[0 0 0.5 1])
for ll = 3:5
    switch ll
        case 3 
           load('conv3_CRF_allXY.mat')
        case 4 
            load('conv4_CRF_allXY.mat')
        case 5
            load('conv5_CRF_allXY.mat')
    end
    indLayer = ll;
    
    cell_ind_list = Cell_array_idx{ll-2}; RF = Cell_RF_layer{ll-2};
    temp_pos = array_fig_pos(ll-2,:);
    for ii = 1:length(cell_ind_list)
        [row,col,chan] = ind2sub(array_sz(ll,:),cell_ind_list(ii));
        temp_ind = sub2ind(array_sz(ll,:),row,col,1);
        RF_face = RF{ii};
        
        Mask = double(Cell_CRF2{find(ind_all_XY == temp_ind)});
        Mask2 = repmat(Mask,[1,1,3]);
        
        subplot(3,6,temp_pos(ii))
        b = imshow(uint8(RF_face.*Mask2)); axis off; axis image
        if ii == 1
            title(['Conv',num2str(ll)])
        end
    end
end
sgtitle({'Receptive fields were obtained by cropping the net input area'; 'of target neurons on the preferred feature image. (Figure 3i)'},'FontSize',fontSize_title);  
toc
% 