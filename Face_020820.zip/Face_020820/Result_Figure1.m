%% Figure 1 : Face-selectivity in pre-trained AlexNet for non-face natural image classification  
fontSize_title = 15; 
fontSize_label = 15; 
fontSize_legend = 12; 

tic
% disp('Figure 1 ... (~ 1 min)')
face_ind = find(cellSB'.*(cellSC==indFace));

%%% Figure 1c : Response matrix of face-selective neurons in pretrained AlexNet
actFaceCell = reshape(permute(act_M(face_ind,:,:),[3,2,1]),[nCLS*nIMG,length(face_ind)])';      % find activity of face-selective neurons
actFaceCell_norm = actFaceCell./repmat(max(actFaceCell,[],2),[1, nCLS*nIMG]);                   % Normalize response of each neuron with thier maximum response 
[~,indSort] = sort(mean(actFaceCell_norm(:,1:nIMG),2),'descend');                               % Sorting with descending order

figure('units','normalized','outerposition',[0 0 0.5 1])
subplot(2,1,1)
imagesc(actFaceCell_norm(indSort,:));
caxis([0 1]); colorbar; colormap(hot); 
xlabel('Image Index','FontSize',fontSize_label); ylabel('Neuron Index','FontSize',fontSize_label);
title('Face-selective response in pretrained AlexNet (Figure 1c)','FontSize',fontSize_label)

%%% Figure 1d : Average tuning curve of face-selective neurons in pretrained AlexNet 
TCface = zeros(length(face_ind),nCLS);
for cc = 1:nCLS
    TCface(:,cc) = mean(actFaceCell_norm(:,(cc-1)*nIMG+1:(cc)*nIMG),2);                         % Calculate average response for each class per neuron: tuning curve
end

subplot(2,1,2)
title('Average tuning curve of face-selective neurons in pretrained AlexNet (Figure 1d)',...
    'FontSize',fontSize_title) 
hold on 
for ii = 1:size(TCface,1)
    h= plot([0:nCLS+1],[mean(TCface(ii,:)) TCface(ii,:) ...
        mean(TCface(ii,:))],'Color',[0 0 0],'linewidth',1.5);                               % Plot tuning curves for each neuron
    h.Color(4)=0.01;                                                                        % Add transparency to line
end
h1 = plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) ... 
    mean(mean(TCface,1),'all')],'Color',[0.98, 0.73 0.23],'linewidth',3);
xlim([0.5 16.5]);
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);       % Plot average tuning curve
ylabel(['Normalized Response'],'FontSize',fontSize_label)
legend(h1,'Averaged','Location','northeast','FontSize',15)


%%% Figure 1h : Performance on the Face classification task using face-selective neurons in pretrained AlexNet
Y = imd.Labels; Label = Y == categorical(cellstr('0_Face'));            % set label: 0 = non-face, 1 = face 
N = 20; nType = 2;                                                      % set number of trial and number of classification category, here it is set 2: face vs non-face                                      

correctRat = zeros(N,nType);
for nn = 1:N
    train_act = []; train_label = [];                                   % Set training set
    test_act = []; test_label = [];                                     % Set test set
    for ii = 1:nCLS 
        actCLS = squeeze(act_M(:,ii,:))';                               % Activity of target class images
        labelCLS = Label(nIMG*(ii-1)+1:nIMG*ii);                        % label of target class images
        
        if ii == indFace                                                % set train and test samples (face class: 60 samples for train and 30 samples for test)
            perm_temp = randperm(100,90);                               % set 90 mother samples
            train_act = [train_act; actCLS(perm_temp(1:60),:)];         % pick 60 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:60),:)]; 
            test_act = [test_act; actCLS(perm_temp(61:90),:)];          % pick 30 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(61:90),:)];
        else
            perm_temp = randperm(100,6);                                % set 6 mother samples
            train_act = [train_act; actCLS(perm_temp(1:4),:)];          % pick 4 random samples among mother samples for train set
            train_label = [train_label; labelCLS(perm_temp(1:4),:)]; 
            test_act = [test_act; actCLS(perm_temp(5:6),:)];            % pick 2 random samples among mother samples for test set
            test_label = [test_label; labelCLS(perm_temp(5:6),:)];
        end
    end
    
    %%% Type 2 SVM : face unit only
    train_act_face = train_act(:,face_ind);                                         % training set using only face cell
    test_act_face = test_act(:,face_ind);                                           % testing set using only face cell
    Mdl = fitcecoc(train_act_face,train_label);                                     % Train SVM
    predict_label = predict(Mdl,test_act_face);                                     % Predcit test label
    correctRat(nn,1) = length(find(test_label == predict_label))...
        ./length(test_label);                                                       % Calculate correct ratio
    
    %%% Type 2 SVM : shuffled response 
    train_act_shf = train_act(randperm(numel(train_act)));                          % training set using only face cell with shuffled response
    train_act_shf = reshape(train_act_shf,[size(train_act,1),size(train_act,2)]);
    test_act_shf = test_act(randperm(numel(test_act)));                             % test set using only face cell with shuffled response
    test_act_shf = reshape(test_act_shf,[size(test_act,1),size(test_act,2)]);
    Mdl = fitcecoc(train_act_shf,train_label);                                      % Train SVM
    predict_label_shf = predict(Mdl,test_act_shf);
    correctRat(nn,2) = length(find(test_label == predict_label_shf))...
        ./length(test_label);                                                       % Calculate correct ratio
end

figure('units','normalized','outerposition',[0 0 0.5 1])
title('SVM performance of face classification task in pretrained AlexNet (Figure 1h)','FontSize',fontSize_title) 
hold on
bar(1,mean(correctRat(:,1)),'FaceColor',[0.98, 0.73 0.23]);
errorbar(1,mean(correctRat(:,1)),std(correctRat(:,1)),'Color','k');
bar(2,mean(correctRat(:,2)),'FaceColor',[0.98, 0.73 0.23]);
errorbar(2,mean(correctRat(:,2)),std(correctRat(:,2)),'Color','k');
name = {'','','Original response','','Response shuffled','',''}; set(gca,'xticklabel',name,'FontSize',fontSize_label); %xlabel('FontSize',fontSize)
ylim([0 1]) 
ylabel('Correct ratio','FontSize',fontSize_label)
toc