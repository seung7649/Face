function net_gau = fun_weight_randomInit(net,Amp_std)
net_gau = net;
temp_net_rand = net_gau.saveobj;

for ii = [2,6,10,12,14]
    temp_weight = net.Layers(ii).Weights; [s1,s2,s3,s4] = size(temp_weight);
    wmean = mean(temp_weight(:)); wstd = std(temp_weight(:));
    temp_weight = wmean+Amp_std.*wstd*randn(size(temp_weight));
    
    temp_bias = net.Layers(ii).Bias; [ss1,ss2,ss3] = size(temp_bias);
    bmean = mean(temp_bias(:)); bstd = std(temp_bias(:));
    temp_bias = bmean+Amp_std.*bstd*randn(size(temp_bias));
    
    temp_net_rand.Layers(ii).Weights = temp_weight;
    temp_net_rand.Layers(ii).Bias = temp_bias;
    
end
net_gau = net_gau.loadobj(temp_net_rand);
end