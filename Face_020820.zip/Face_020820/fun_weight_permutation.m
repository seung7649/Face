function net_rand = fun_weight_permutation(net)
net_rand = net;
temp_net_rand = net_rand.saveobj;

for ii = [2,6,10,12,14]
    temp_weight = net.Layers(ii).Weights; [s1,s2,s3,s4] = size(temp_weight);
    temp_weight = temp_weight(randperm(s1*s2*s3*s4)); temp_weight = reshape(temp_weight,[s1,s2,s3,s4]);
    
    temp_bias = net.Layers(ii).Bias; [ss1,ss2,ss3] = size(temp_bias);
    temp_bias = temp_bias(randperm(ss1*ss2*ss3)); temp_bias = reshape(temp_bias,[ss1,ss2,ss3]);
    
    temp_net_rand.Layers(ii).Weights = temp_weight;
    temp_net_rand.Layers(ii).Bias = temp_bias;
end
net_rand = net_rand.loadobj(temp_net_rand);
end