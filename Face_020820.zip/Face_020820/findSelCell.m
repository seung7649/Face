function Cell_selective_idx = findSelCell(act_M,nCLS,SC,pThr,trgCLS)
% response of all neurons to images of each class
if trgCLS == 0
    Cell_selective_idx = zeros(1,size(SC,1));
    for nn = 1:size(SC,1)
        ref_class = SC(nn);
        cc_list = 1:16;
        cc_list(cc_list==ref_class) = [];
        p_list = zeros(1,15);
        for cc = 1:15
            p_list(cc) = ranksum(squeeze(act_M(nn,ref_class,:)),squeeze(act_M(nn,cc_list(cc),:)));
        end
        Cell_selective_idx(nn) = max(p_list)<pThr;
    end
else
    Cell_selective_idx = zeros(1,size(SC,1));
    iidd = find(SC == trgCLS);
    for nn = 1:length(iidd)
        ref_class = SC(iidd(nn));
        cc_list = 1:16;
        cc_list(cc_list==ref_class) = [];
        p_list = zeros(1,15);
        for cc = 1:15
            p_list(cc) = ranksum(squeeze(act_M(iidd(nn),ref_class,:)),squeeze(act_M(iidd(nn),cc_list(cc),:)));
        end
        Cell_selective_idx(iidd(nn)) = max(p_list)<pThr;
    end
end