%% Figure 4 : Face-selectivity induced by variation in convolutional weights
fontSize_title = 15; 
fontSize_label = 15; 
fontSize_legend = 12; 
tic
%%% Figure 4a The untrained AlexNet by randomly permuting the weights in each convolutional layer (Figure 4a)
layers_ind = [2,6,10,12,14]; 
edgesh = -0.15:0.005:0.15; % bin edges of weight distribution
wrange = -0.15:0.0005:0.15; % range of weights
array_color = [0 1 1; 0 0.8 0.8; 0 0.8 0.2]; % array of color code for different condition of weight variation

figure('units','normalized','outerposition',[0 0 0.5 1])
weight_tot = []; % stacking all convolutional weigths of each layer 
for ind_tl = 1:length(layers_ind)
    targetlayer_ind = layers_ind(ind_tl);
    weight_conv = net.Layers(targetlayer_ind ,1).Weights; % convolutional weigths of each layer 
    bias_conv = net.Layers(targetlayer_ind ,1).Bias;
    weight_tot = [weight_tot;weight_conv(:)];
end

subplot(6,4,[1 2 5 6])
hold on 
histogram(weight_tot(:),edgesh, 'Normalization', 'probability','FaceColor',[0.5 0.5 0.5]) % histogram of all convolutional weigths of each layer 
% set(gcf,'Position',[100 100 1000 400])
xlabel('Weight','FontSize',15); ylabel('Ratio','FontSize',15); ylim([0 0.2]); yticks([0 0.1 0.2]); xlim([-0.08 0.08]); xticks([-0.08 0 0.08])

% randomly drawn from a Gaussian distribution that fit the weight distribution of the pre-trained state
for ii = 2:length(Cell_net_gau)
    net_rand_tmp = Cell_net_gau{ii};
    weight_tot = []; % stacking all convolutional weigths of each layer 
    for ind_tl = 1:length(layers_ind)
        targetlayer_ind = layers_ind(ind_tl);
        weight_conv = net_rand_tmp.Layers(targetlayer_ind ,1).Weights; % convolutional weigths of each layer  
        weight_tot = [weight_tot;weight_conv(:)];
    end
    wstd = std(weight_tot(:)); wmean = mean(weight_tot(:));
    Gausstmp = exp(-(wrange-wmean).^2/(2*wstd^2)); Gausstmp = Gausstmp/max(Gausstmp); % fitting the convolutional weight distribution to Gaussian distribtion
    subplot(6,4,[3 4 7 8])
    hold on;plot(wrange(1:end), Gausstmp(1:end), 'Color', array_color(ii-1,:),'linewidth',1.5)  

end
legend({'60%', '80%', '100%'},'FontSize',fontSize_legend)
xlabel('Weight','FontSize',fontSize_label); ylabel('Ratio','FontSize',fontSize_label); ylim([0 1.2]); yticks([]); xlim([-0.08 0.08]); xticks([-0.08 0 0.08])  
  

% Visualizing example filter    
for ii = 1:length(Cell_net_gau)
    if ii==1
        nettmp = net;
    else
        nettmp = Cell_net_gau{ii};
    end
    
    tmp = nettmp.Layers(layers_ind(1)).Weights;sztmp = size(tmp,4); indtmpp=randi(sztmp, [1,3]);
    for jj = 1:length(indtmpp)
        tmp2 = squeeze(tmp(:,:,1,indtmpp(jj)));
        if ii==0 && face_ind ==1
            caxtmp = max(abs(min(tmp2(:))), abs(max(tmp2(:))));
        end

        subplot(6,4,4*(jj-1)+12+ii); imagesc(squeeze(tmp(:,:,1,indtmpp(jj)))); axis image off; caxis([-2*caxtmp 2*caxtmp])
        if ii~=1
            if jj ==1;title(['Weight variation = ' num2str(100-20*(ii-1)) '%'],'FontSize',fontSize_label);end   
        else
            if jj ==1;title(['Pretrained'],'FontSize',fontSize_label);end   
        end
    end
    colormap(gray);
end
sgtitle({'Untrained AlexNet : ';'Randomly sampled from controlled Gaussian distribution of pretrained AlexNet  (Figure.4a)'},'FontSize',fontSize_title)   


%%% Figure 4b : Average of all tuning curves for face-selective neurons across different levels of weight variation
array_color = [0 1 1; 0 0.8 0.8; 0 0.8 0.2];
figure('units','normalized','outerposition',[0 0 0.5 1])
hold on
% measuring tuning curve for face-selective neurons across different levels of weight variation
for ii = 2:length(stdArray)
    act_gau_M = act_gau_C{ii};  % response matrix
    cellSB_gau = cellSB_gau_C{ii};
    cellSC_gau = cellSC_gau_C{ii};
    ind_temp = cellSB_gau'.*(cellSC_gau==1);
    ind_gau = find(ind_temp);  % index of face-selective neurons
    
    Map_res_face = zeros(nCLS*nIMG,length(ind_temp)); % response matrix [ # of total images x # of face selective neurons ]
    array_init_ind = [0:100:1500];
    for jj = 1:length(ind_temp)
        for cc = 1:nCLS
            Map_res_face(array_init_ind(cc)+1:array_init_ind(cc)+100,jj) = squeeze(act_gau_M(jj,cc,:));
        end
    end
    
    TCface = zeros(length(ind_gau),nCLS); % tuning curve [ # of face selective neurons x # of class ]     
    for cc = 1:nCLS
        tempDATA_res = transpose(squeeze(act_gau_M(:,cc,:)));
%         tempDATA_face = tempDATA_res./max(Map_res_face,[],1);
        tempDATA_face = tempDATA_res;
        TCface(:,cc) = mean(tempDATA_face(:,ind_gau),1);
    end
    
    plot([0:nCLS+1],[mean(mean(TCface,1),'all') mean(TCface,1) mean(mean(TCface,1),'all')],'Color',array_color(ii-1,:),'linewidth',3);
end
xlim([0.5 16.5]); 
name = STR_LABEL; set(gca, 'XTick', 1:length(name),'XTickLabel',name);xtickangle(45);
ylabel(['Averaged response'],'FontSize',fontSize_label)     
title({'Averaged tuning curves for face-selective neurons'; 'across different levels of weight variation (Figure 4b)'},'FontSize',fontSize_title)   
legend('weight variation = 60%','weight variation = 80%','weight variation = 100%','FontSize',fontSize_legend)  

%%% Figure 4c : Preferred feature image as the weight variation 
tic
Cell_RF_w = cell(1,length(stdArray)); % array of degree of weight variation
temp_idx = [5 4 3 2];
for ii = 1:length(stdArray)
    act_gau_M = act_gau_C{ii}; % response matrix
    cellSB_gau = cellSB_gau_C{ii};
    cellSC_gau = cellSC_gau_C{ii};
    ind_temp = cellSB_gau'.*(cellSC_gau==1);
    ind_gau = find(ind_temp); % index of face-selective neurons
    
    SI_list_face_gau = faceSI_gau_C{ii}; % array of face-selectivity index 
    [SI_sort,ind_SI_sort] = sort(SI_list_face_gau,'descend'); % sorting by descrasing order
    cell_ind_list = ind_gau(ind_SI_sort(temp_idx(ii)));  % selecting sample face-selective neuron with top5 selectivity 
    Cell_RF_w{ii} = prefFeatureIMG(act_gau_M,inpSize,IMG_M,cell_ind_list); % preferred feature image of a face-selective neuron 
end
toc


figure('units','normalized','outerposition',[0 0 1 0.5])  
for ii = 1:length(stdArray)
    
    subplot(1,length(stdArray),ii)
    a = Cell_RF_w{ii};
    imshow(uint8(a{1}));
    title(['Weight variation : ',num2str(stdArray(ii)*100),' %'],'FontSize',fontSize_label)  
end
sgtitle({'Preferred feature images of face-selective neurons across different levels of weight variation (Figure 4c)'},'FontSize',fontSize_title) 
toc